using System;
using System.Threading;
using System.Threading.Tasks;

namespace Wells.Fargo.HttpClientHelper
{
    public static class AsyncHelper
    {
        private static readonly TaskFactory SyncTaskFactory = new
            TaskFactory(CancellationToken.None, TaskCreationOptions.None, TaskContinuationOptions.None, TaskScheduler.Default);

        public static TResult RunSync<TResult>(Func<Task<TResult>> func)
        {
            return SyncTaskFactory.StartNew(func).Unwrap().GetAwaiter().GetResult();
        }

        public static void RunSync(Func<Task> func)
        {
            SyncTaskFactory.StartNew(func).Unwrap().GetAwaiter().GetResult();
        }
    }
}