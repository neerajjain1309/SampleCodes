using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Cache;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Wells.Fargo.HttpClientHelper.Interface;

namespace Wells.Fargo.HttpClientHelper
{
    public class HttpClient : HttpClientBase, IHttpClient
    {
        private readonly ISsoToken _ssoToken;
        private readonly IWebRequestDecorator _webRequestDecorator;

        public HttpClient(ISsoToken ssoToken, IWebRequestDecorator webRequestDecorator)
        {
            _ssoToken = ssoToken;
            _webRequestDecorator = webRequestDecorator;
        }

        public T Delete<T>(string url)
        {
            return AsyncHelper.RunSync(() => ExecuteHttpRequestAsync<T>(url, null, HttpDelete, HttpTimeout));
        }

        public T Delete<T>(string url, object body)
        {
            return AsyncHelper.RunSync(() => ExecuteHttpRequestAsync<T>(url, JsonConvert.SerializeObject(body), HttpDelete, HttpTimeout));
        }

        public T Get<T>(string url)
        {
            return AsyncHelper.RunSync(() => GetAsync<T>(url, HttpTimeout));
        }

        public T Get<T>(string url, int httpTimeOut)
        {
            return AsyncHelper.RunSync(() => GetAsync<T>(url, httpTimeOut));
        }

        public T Get<T>(string url, IDictionary<string, string> parameters)
        {
            throw new NotImplementedException();
        }

        public T Get<T>(string url, int httpTimeOut, IDictionary<string, string> parameters)
        {
            throw new NotImplementedException();
        }

        public async Task<T> GetAsync<T>(string url, int httpTimeOut)
        {
            return await ExecuteHttpRequestAsync<T>(url, null, HttpGet, httpTimeOut);
        }

        public T Post<T>(string url, object body)
        {
            return AsyncHelper.RunSync(() => PostAsync<T>(url, body, HttpTimeout));
        }

        public T Post<T>(string url, object body, int httpTimeOut)
        {
            return AsyncHelper.RunSync(() => PostAsync<T>(url, body, httpTimeOut));
        }

        public async Task<T> PostAsync<T>(string url, object body, int httpTimeOut)
        {
            return await ExecuteHttpRequestAsync<T>(url, JsonConvert.SerializeObject(body), HttpPost, httpTimeOut);
        }

        public T Put<T>(string url, object body)
        {
            return AsyncHelper.RunSync(() => PutAsync<T>(url, body, HttpTimeout));
        }

        public T Put<T>(string url, object body, int httpTimeOut)
        {
            return AsyncHelper.RunSync(() => PutAsync<T>(url, body, httpTimeOut));
        }

        public async Task<T> PutAsync<T>(string url, object body, int httpTimeOut)
        {
            return await ExecuteHttpRequestAsync<T>(url, JsonConvert.SerializeObject(body), HttpPut, httpTimeOut);
        }

        private async Task<T> ExecuteHttpRequestAsync<T>(string url, string body, string httpMethod, int httpTimeOut)
        {
            try
            {
                var request = CreateWebRequest(url, httpMethod, httpTimeOut);
                if (!string.IsNullOrWhiteSpace(body))
                {
                    var requestBody = Encoding.UTF8.GetBytes(body);
                    request.ContentLength = requestBody.Length;
                    using (var requestStream = request.GetRequestStream())
                    {
                        requestStream.Write(requestBody, 0, requestBody.Length);
                    }
                }
                var response = await RetrieveWebResponseAsync(request);
                string output;
                using (var stream = new StreamReader(response.GetResponseStream()))
                {
                    output = stream.ReadToEnd();
                }

                var result = (T)JsonConvert.DeserializeObject(output, typeof(T));
                return result;
            }
            catch (WebException webException)
            {
                throw;
            }
        }

        private HttpWebRequest CreateWebRequest(string uri, string httpMethod, int httpTimeOut)
        {
            var webRequest = (HttpWebRequest)WebRequest.Create(uri);

            webRequest.Method = httpMethod;
            webRequest.Timeout = httpTimeOut;
            webRequest.Headers.Add("timeout", httpTimeOut.ToString());
            //webRequest.Credentials = CredentialCache.DefaultCredentials;
            webRequest = _webRequestDecorator.DecorateWebRequest(webRequest, _ssoToken);
            return webRequest;
        }
    }
}