using System;

namespace Wells.Fargo.HttpClientHelper
{
    public static class ParameterChecker
    {
        public static T NotNull<T>(T parameter, string parameterName)
        {
            if (ReferenceEquals(null, parameter))
            {
                throw new ArgumentNullException(parameterName);
            }
            return parameter;
        }

        public static string NotNullOrEmpty(string parameter, string parameterName)
        {
            if (ReferenceEquals(null, parameter))
            {
                throw new ArgumentNullException(parameterName);
            }
            if (string.IsNullOrEmpty(parameter))
            {
                throw new ArgumentException("Illegal empty string", parameterName);
            }
            return parameter;
        }
    }
}