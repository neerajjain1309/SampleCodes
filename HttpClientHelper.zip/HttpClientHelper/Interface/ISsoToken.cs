using System;

namespace Wells.Fargo.HttpClientHelper.Interface
{
    /// <summary>
    /// SSO Token interface
    /// </summary>
    public interface ISsoToken
    {
        /// <summary>
        /// Name of the application the token is for
        /// </summary>
        string ApplicationName { get; }

        /// <summary>
        /// The token string 
        /// </summary>
        string TokenString { get; }

        /// <summary>
        /// The date time that the toekn will expire at
        /// </summary>
        DateTime ExpiryDate { get; }

        /// <summary>
        /// Function getting a valid Token string
        /// </summary>
        /// <returns></returns>
        string GetValidTokenString();

        string UserName { get; }
    }

    
}