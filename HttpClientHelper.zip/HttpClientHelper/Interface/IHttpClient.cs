﻿using System;
using System.Collections.Generic;

namespace Wells.Fargo.HttpClientHelper.Interface
{
    public interface IHttpClient
    {
        /// <summary>
        /// Specify what the http timeout should be
        /// </summary>
        int DefaultHttpTimeout { get; }

        T Get<T>(string url);

        T Get<T>(string url, int httpTimeOut);

        T Get<T>(string url, IDictionary<string, string> parameters);

        T Get<T>(string url, int httpTimeOut, IDictionary<string, string> parameters);

        T Post<T>(string url, object body);

        T Post<T>(string url, object body, int httpTimeOut);

        T Put<T>(string url, object body);

        T Put<T>(string url, object body, int httpTimeOut);

        T Delete<T>(string url);

        T Delete<T>(string url, object body);

    }

}
