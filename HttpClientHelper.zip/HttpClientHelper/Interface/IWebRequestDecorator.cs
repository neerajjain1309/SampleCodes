using System.Net;

namespace Wells.Fargo.HttpClientHelper.Interface
{
    public interface IWebRequestDecorator
    {
        HttpWebRequest DecorateWebRequest(HttpWebRequest webRequest, ISsoToken ssoToken);
    }
}