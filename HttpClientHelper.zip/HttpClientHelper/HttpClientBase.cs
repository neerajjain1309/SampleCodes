using System;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Wells.Fargo.HttpClientHelper
{
    public abstract class HttpClientBase
    {
        protected const string HttpGet = "GET";
        protected const string HttpDelete = "DELETE";
        protected const string HttpPut = "PUT";
        protected const string HttpPost = "POST";

        //private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        /// <summary>
        /// timeout for http requests in milliseconds (defaults to 2 minutes)
        /// </summary>
        protected int HttpTimeout = 120000;

        public int DefaultHttpTimeout
        {
            get { return HttpTimeout; }
        }

        protected async Task<HttpWebResponse> RetrieveWebResponseAsync(HttpWebRequest request)
        {
            ParameterChecker.NotNull(request, "request");
            var requestId = Guid.NewGuid().ToString();
            HttpWebResponse response = null;

            //Log.InfoFormat("Sending HTTP request id[{0}] method[{1}] url[{2}]", requestId, request.Method, request.RequestUri);

            try
            {
                if (request.Timeout < 1)
                    request.Timeout = HttpTimeout;
               
                var task = Task<WebResponse>.Factory.FromAsync(request.BeginGetResponse, request.EndGetResponse, request);

                if (Task.WaitAny(new Task[] { task }, request.Timeout) == -1)
                    throw new TimeoutException();

                response = (HttpWebResponse)await task;
            }
            catch (WebException ex)
            {
                var httpWebResponse = ex.Response as HttpWebResponse;
                if (httpWebResponse != null && httpWebResponse.StatusCode == HttpStatusCode.InternalServerError)
                {
                    var stream = ex.Response.GetResponseStream();
                    if (stream != null && stream.CanRead)
                    {
                        var buffer = new byte[stream.Length];
                        stream.Read(buffer, 0, (int)stream.Length);
                        var str = Encoding.UTF8.GetString(buffer);
                        if (!string.IsNullOrEmpty(str))
                        {
                            var message = string.Format("{0}\n {1}", ex.Message, str);
                            throw new WebException(message, ex, ex.Status, ex.Response);
                        }
                    }
                }
                else
                {
                    //Log.Error(string.Format("Problem when retrieving response for URL[{0}] Method[{1}]",
                    //    request.RequestUri.AbsoluteUri,
                    //    request.Method), ex);

                    throw;
                }
            }
            catch (Exception ex)
            {
                //Log.Error(string.Format("Problem when retrieving response for URL[{0}] Method[{1}]",
                //                        request.RequestUri.AbsoluteUri,
                //                        request.Method),
                //          ex);
                throw;
            }

            return response;
        }
    }
}