using System;
using System.Net;
using Wells.Fargo.HttpClientHelper.Interface;

namespace Wells.Fargo.HttpClientHelper
{
    public class DefaultWebRequestDecorator : IWebRequestDecorator
    {
        public HttpWebRequest DecorateWebRequest(HttpWebRequest webRequest, ISsoToken ssoToken)
        {
            var validTokenString = ssoToken.GetValidTokenString();
            if (!string.IsNullOrEmpty(validTokenString))
                webRequest.Headers.Add("sso-token", validTokenString);
            webRequest.ContentType = "application/json";
            return webRequest;
        }
    }
}