using System;
using Wells.Fargo.HttpClientHelper.Interface;

namespace Wells.Fargo.HttpClientHelper
{
    public class EmptyToken : ISsoToken
    {
        private readonly string _validToken;

        public EmptyToken()
            : this(string.Empty)
        { }

        public EmptyToken(string validToken)
        {
            _validToken = validToken ?? string.Empty;
        }

        public string ApplicationName
        {
            get { return string.Empty; }
        }

        public string TokenString
        {
            get { return string.Empty; }
        }

        public DateTime ExpiryDate
        {
            get { return DateTime.MaxValue; }
        }

        public string GetValidTokenString()
        {
            return _validToken;
        }

        public string UserName
        {
            get { return string.Empty; }
        }
    }
}